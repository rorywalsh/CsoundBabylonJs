WebAudio Cosund scripts should be copied here. Use `../../update_example_libs_from_dist.sh` for this purpose.
